#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TASK 3: Secure Coding Review
CodeAlpha Cyber Security Internship

A static code analyzer that detects common security vulnerabilities:
- SQL Injection
- Command Injection
- Hardcoded secrets
- Insecure deserialization
- XSS vulnerabilities
- Weak cryptography
- Path traversal
- Insecure file permissions
- Debug mode enabled
- Insecure random numbers
- SSRF vulnerabilities

Features:
- Multi-language support (Python, JS, PHP, Java, Go, Ruby)
- CWE mapping for each vulnerability
- Severity classification (CRITICAL, HIGH, MEDIUM, LOW)
- JSON report export
- Colored console output
"""

import re
import sys
import os
import json
import datetime
import tempfile
import shutil
from dataclasses import dataclass, asdict
from typing import List, Dict, Optional
from collections import Counter

# Color support
try:
    from colorama import init, Fore, Style
    init(autoreset=True)
except ImportError:
    class _Fore:
        RED = '\033[91m'; GREEN = '\033[92m'; YELLOW = '\033[93m'
        BLUE = '\033[94m'; MAGENTA = '\033[95m'; CYAN = '\033[96m'
        WHITE = '\033[97m'; RESET = '\033[0m'
    class _Style:
        BRIGHT = '\033[1m'; DIM = '\033[2m'; RESET_ALL = '\033[0m'
    Fore = _Fore(); Style = _Style()

# ============================================================
# Data Classes
# ============================================================
@dataclass
class Vulnerability:
    file: str
    line: int
    severity: str
    category: str
    description: str
    code_snippet: str
    recommendation: str
    cwe_id: str

# ============================================================
# Secure Code Analyzer Engine
# ============================================================
class SecureCodeAnalyzer:
    def __init__(self):
        self.vulns: List[Vulnerability] = []
        self.rules = self._load_rules()
        self.files_scanned = 0
        self.lines_scanned = 0
    
    def _load_rules(self):
        return {
            'SQL_INJECTION': {
                'patterns': [
                    r'(?:execute|query|raw|cursor\(\)\.execute)\s*\(\s*[f"\'].*?(%s|\{.*?\}|\+).*?[\"\']',
                    r'f["\']\s*SELECT\s+.*?(?:FROM|WHERE|INSERT|UPDATE|DELETE).*?\{.*?\}.*?["\']',
                    r'["\']\s*SELECT\s+.*?\+\s*(?:request|req|params|args|input)',
                ],
                'severity': 'CRITICAL',
                'description': 'Potential SQL Injection vulnerability detected',
                'recommendation': 'Use parameterized queries with placeholders (? or %s). Never concatenate user input into SQL.',
                'cwe': 'CWE-89',
                'langs': ['.py', '.php', '.js', '.java', '.go']
            },
            'COMMAND_INJECTION': {
                'patterns': [
                    r'(?:os\.system|subprocess\.call|subprocess\.run|subprocess\.Popen|eval|exec)\s*\(\s*[f"\'].*?\{.*?\}.*?["\']',
                    r'(?:os\.system|subprocess\.call|subprocess\.run)\s*\(\s*.*?\+\s*(?:request|req|params|args)',
                ],
                'severity': 'CRITICAL',
                'description': 'Potential Command Injection via string interpolation',
                'recommendation': 'Use subprocess with list arguments, avoid shell=True. Validate all inputs with allowlists.',
                'cwe': 'CWE-78',
                'langs': ['.py']
            },
            'HARDCODED_SECRET': {
                'patterns': [
                    r'(?:password|passwd|secret|api_key|apikey|token|private_key|aws_secret|db_password)\s*[=:]\s*["\'][^"\']{4,}["\']',
                    r'(?:SECRET_KEY|API_KEY|AUTH_TOKEN)\s*=\s*["\'][^"\']{8,}["\']',
                ],
                'severity': 'HIGH',
                'description': 'Hardcoded secret or credential detected in source code',
                'recommendation': 'Use environment variables, .env files, or secure vaults (AWS Secrets Manager, HashiCorp Vault).',
                'cwe': 'CWE-798',
                'langs': ['.py', '.js', '.php', '.java', '.go', '.rb']
            },
            'INSECURE_DESERIALIZATION': {
                'patterns': [
                    r'(?:pickle\.loads|yaml\.load\s*\(|yaml\.unsafe_load|marshal\.loads|eval\s*\(|exec\s*\()',
                ],
                'severity': 'CRITICAL',
                'description': 'Insecure deserialization detected - can lead to RCE',
                'recommendation': 'Use yaml.safe_load(), json.loads(), or validate and sanitize input before deserialization.',
                'cwe': 'CWE-502',
                'langs': ['.py']
            },
            'XSS_VULNERABILITY': {
                'patterns': [
                    r'(?:render_template_string|\.format\s*\(.*?(?:request\.|user_|input|params))',
                    r'f["\'].*?\{.*?(?:request\.|user_|input|params).*?\}.*?["\']',
                    r'(?:innerHTML|document\.write)\s*=\s*.*?\+',
                ],
                'severity': 'HIGH',
                'description': 'Potential Cross-Site Scripting (XSS) vulnerability',
                'recommendation': 'Use auto-escaping template engines, sanitize user input with libraries like bleach or DOMPurify.',
                'cwe': 'CWE-79',
                'langs': ['.py', '.js', '.php']
            },
            'WEAK_HASH': {
                'patterns': [
                    r'(?:hashlib\.md5|hashlib\.sha1|md5\s*\(|sha1\s*\(|MD5\(|SHA1\()',
                ],
                'severity': 'MEDIUM',
                'description': 'Weak cryptographic hash function used',
                'recommendation': 'Use SHA-256 or stronger. For passwords, use bcrypt, scrypt, or Argon2.',
                'cwe': 'CWE-328',
                'langs': ['.py', '.js', '.php', '.java']
            },
            'PATH_TRAVERSAL': {
                'patterns': [
                    r'(?:open\s*\(|file\s*\(|read\s*\(|write\s*\(|send_file\s*\().*?(?:request\.|input\(|argv|params)',
                    r'(?:os\.path\.join|Path\().*?(?:request\.|input\(|argv)',
                ],
                'severity': 'HIGH',
                'description': 'Potential Path Traversal vulnerability',
                'recommendation': 'Validate and sanitize file paths, use allowlists, restrict to specific directories.',
                'cwe': 'CWE-22',
                'langs': ['.py', '.php', '.js']
            },
            'DEBUG_ENABLED': {
                'patterns': [
                    r'(?:DEBUG\s*=\s*True|debug\s*=\s*True|app\.run\s*\(.*debug\s*=\s*True)',
                    r'(?:app\.debug\s*=\s*True|FLASK_DEBUG\s*=\s*1)',
                ],
                'severity': 'MEDIUM',
                'description': 'Debug mode enabled - exposes sensitive information',
                'recommendation': 'Set DEBUG=False in production. Use environment variables to control debug mode.',
                'cwe': 'CWE-489',
                'langs': ['.py']
            },
            'INSECURE_RANDOM': {
                'patterns': [
                    r'(?:random\.random|random\.randint|random\.choice|random\.shuffle|Math\.random)\s*\(',
                ],
                'severity': 'LOW',
                'description': 'Insecure random number generation for security purposes',
                'recommendation': 'Use secrets module (Python) or crypto.randomBytes (Node.js) for cryptographic operations.',
                'cwe': 'CWE-338',
                'langs': ['.py', '.js']
            },
            'SSRF_VULNERABILITY': {
                'patterns': [
                    r'(?:requests\.get|urllib\.request\.urlopen|urlopen|fetch|axios\.get)\s*\(\s*[f"\'].*?\{.*?\}.*?["\']',
                    r'(?:requests\.get|urllib\.request\.urlopen)\s*\(\s*.*?\+\s*(?:request\.|input|params)',
                ],
                'severity': 'HIGH',
                'description': 'Potential Server-Side Request Forgery (SSRF)',
                'recommendation': 'Validate and sanitize URLs, use allowlists for domains, disable redirects.',
                'cwe': 'CWE-918',
                'langs': ['.py', '.js', '.php']
            },
            'INSECURE_CORS': {
                'patterns': [
                    r'(?:Access-Control-Allow-Origin\s*:\s*\*|cors\(.*origin\s*=\s*["\']\*["\'])',
                ],
                'severity': 'MEDIUM',
                'description': 'Insecure CORS configuration allowing any origin',
                'recommendation': 'Specify exact allowed origins. Never use wildcard (*) in production.',
                'cwe': 'CWE-942',
                'langs': ['.py', '.js', '.php']
            },
            'HARDCODED_IP': {
                'patterns': [
                    r'["\']\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}["\']',
                ],
                'severity': 'LOW',
                'description': 'Hardcoded IP address detected',
                'recommendation': 'Use configuration files or environment variables for IP addresses.',
                'cwe': 'CWE-547',
                'langs': ['.py', '.js', '.php', '.java', '.go', '.rb']
            },
        }
    
    def analyze_file(self, filepath: str):
        ext = os.path.splitext(filepath)[1].lower()
        try:
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                lines = f.readlines()
        except Exception as e:
            print(f"{Fore.YELLOW}[!] Error reading {filepath}: {e}{Fore.RESET}")
            return
        
        self.files_scanned += 1
        self.lines_scanned += len(lines)
        
        for rule_name, rule in self.rules.items():
            if ext not in rule['langs']:
                continue
            for line_num, line in enumerate(lines, 1):
                for pattern in rule['patterns']:
                    if re.search(pattern, line, re.IGNORECASE):
                        # Avoid duplicates
                        already_found = any(v.file == filepath and v.line == line_num and v.category == rule_name for v in self.vulns)
                        if already_found:
                            continue
                        self.vulns.append(Vulnerability(
                            file=filepath,
                            line=line_num,
                            severity=rule['severity'],
                            category=rule_name,
                            description=rule['description'],
                            code_snippet=line.strip()[:120],
                            recommendation=rule['recommendation'],
                            cwe_id=rule['cwe']
                        ))
                        break
    
    def analyze_directory(self, directory: str, extensions=None):
        if extensions is None:
            extensions = ['.py', '.js', '.php', '.java', '.go', '.rb']
        
        for root, _, files in os.walk(directory):
            for file in files:
                if any(file.endswith(ext) for ext in extensions):
                    self.analyze_file(os.path.join(root, file))
    
    def generate_report(self, output_file=None):
        report = {
            'scan_info': {
                'timestamp': datetime.datetime.now().isoformat(),
                'files_scanned': self.files_scanned,
                'lines_scanned': self.lines_scanned,
            },
            'summary': {
                'total_vulnerabilities': len(self.vulns),
                'critical': sum(1 for v in self.vulns if v.severity == 'CRITICAL'),
                'high': sum(1 for v in self.vulns if v.severity == 'HIGH'),
                'medium': sum(1 for v in self.vulns if v.severity == 'MEDIUM'),
                'low': sum(1 for v in self.vulns if v.severity == 'LOW'),
            },
            'vulnerabilities': [asdict(v) for v in self.vulns]
        }
        
        # Print colored report
        print(f"\n{Fore.CYAN}{Style.BRIGHT}{'='*70}{Fore.RESET}")
        print(f"{Fore.CYAN}{Style.BRIGHT}           SECURE CODE REVIEW REPORT{Fore.RESET}")
        print(f"{Fore.CYAN}{Style.BRIGHT}{'='*70}{Fore.RESET}")
        print(f"\n  {Fore.WHITE}Files Scanned:{Fore.RESET}  {Fore.YELLOW}{self.files_scanned}{Fore.RESET}")
        print(f"  {Fore.WHITE}Lines Scanned:{Fore.RESET}  {Fore.YELLOW}{self.lines_scanned}{Fore.RESET}")
        print(f"\n  {Fore.WHITE}Total Vulnerabilities:{Fore.RESET} {Fore.YELLOW}{report['summary']['total_vulnerabilities']}{Fore.RESET}")
        print(f"    {Fore.RED}CRITICAL:{Fore.RESET} {report['summary']['critical']}")
        print(f"    {Fore.YELLOW}HIGH:{Fore.RESET}     {report['summary']['high']}")
        print(f"    {Fore.BLUE}MEDIUM:{Fore.RESET}   {report['summary']['medium']}")
        print(f"    {Fore.GREEN}LOW:{Fore.RESET}      {report['summary']['low']}")
        
        # Category breakdown
        cats = Counter(v.category for v in self.vulns)
        if cats:
            print(f"\n  {Fore.WHITE}Vulnerability Categories:{Fore.RESET}")
            for cat, count in cats.most_common():
                print(f"    {cat:25s} {count:3d}")
        
        # Detailed findings
        for sev in ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW']:
            sev_vulns = [v for v in self.vulns if v.severity == sev]
            if sev_vulns:
                color = Fore.RED if sev == 'CRITICAL' else (Fore.YELLOW if sev == 'HIGH' else (Fore.BLUE if sev == 'MEDIUM' else Fore.GREEN))
                print(f"\n{color}{Style.BRIGHT}{'='*70}{Fore.RESET}")
                print(f"{color}{Style.BRIGHT}  {sev} SEVERITY ({len(sev_vulns)} findings){Fore.RESET}")
                print(f"{color}{Style.BRIGHT}{'='*70}{Fore.RESET}")
                for v in sev_vulns:
                    print(f"\n  {Fore.CYAN}[{v.cwe_id}] {v.category}{Fore.RESET}")
                    print(f"  {Fore.WHITE}File:{Fore.RESET} {v.file}:{v.line}")
                    print(f"  {Fore.WHITE}Code:{Fore.RESET} {v.code_snippet}")
                    print(f"  {Fore.GREEN}Fix: {v.recommendation}{Fore.RESET}")
        
        if output_file:
            with open(output_file, 'w') as f:
                json.dump(report, f, indent=2)
            print(f"\n{Fore.GREEN}[+] Report saved to {output_file}{Fore.RESET}")
        
        return report

# ============================================================
# Test Vulnerable Application Generator
# ============================================================
def create_test_vulnerable_app():
    return '''import sqlite3, os, pickle, hashlib, random
from flask import Flask, request, render_template_string, send_file
import requests

app = Flask(__name__)
app.config['SECRET_KEY'] = 'hardcoded_secret_key_12345'
DB_PASSWORD = "super_secret_db_pass_123"

@app.route('/login')
def login():
    username = request.args.get('user')
    password = request.args.get('pass')
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    query = f"SELECT * FROM users WHERE username='{username}' AND password='{password}'"
    cursor.execute(query)
    return str(cursor.fetchall())

@app.route('/run')
def run_command():
    cmd = request.args.get('cmd')
    os.system(f"echo {cmd}")
    return "Done"

@app.route('/load')
def load_data():
    data = request.data
    obj = pickle.loads(data)
    return str(obj)

@app.route('/hash')
def hash_password():
    pwd = request.args.get('pwd')
    return hashlib.md5(pwd.encode()).hexdigest()

@app.route('/page')
def page():
    name = request.args.get('name')
    return render_template_string(f"<h1>Hello {name}</h1>")

@app.route('/file')
def read_file():
    f = request.args.get('file')
    return open(f).read()

@app.route('/fetch')
def fetch_url():
    url = request.args.get('url')
    return requests.get(url).text

@app.route('/random')
def get_random():
    return str(random.randint(1, 100))

if __name__ == '__main__':
    app.run(debug=True)
'''

# ============================================================
# Main
# ============================================================
def print_help():
    print("""
Usage: python3 secure_coding_review.py [OPTIONS] [PATH]
Options:
  -o, --output FILE   Save report to JSON file
  -h, --help          Show this help message

Examples:
  python3 secure_coding_review.py                    # Analyze test app
  python3 secure_coding_review.py /path/to/code      # Analyze directory
  python3 secure_coding_review.py -o report.json     # Save to file
""")

def main():
    import datetime
    args = sys.argv[1:]
    output = None
    target = None
    
    i = 0
    while i < len(args):
        if args[i] in ('-o', '--output') and i + 1 < len(args):
            output = args[i+1]; i += 2
        elif args[i] in ('-h', '--help'):
            print_help(); return
        elif not args[i].startswith('-'):
            target = args[i]; i += 1
        else:
            i += 1
    
    print(f"{Fore.CYAN}{Style.BRIGHT}{'='*70}{Fore.RESET}")
    print(f"{Fore.CYAN}{Style.BRIGHT}      CODEALPHA SECURE CODING REVIEW TOOL{Fore.RESET}")
    print(f"{Fore.CYAN}{Style.BRIGHT}{'='*70}{Fore.RESET}")
    
    analyzer = SecureCodeAnalyzer()
    
    if target and os.path.exists(target):
        if os.path.isdir(target):
            print(f"\n[+] Scanning directory: {target}")
            analyzer.analyze_directory(target)
        elif os.path.isfile(target):
            print(f"\n[+] Scanning file: {target}")
            analyzer.analyze_file(target)
    else:
        # Create and scan test vulnerable app
        test_dir = tempfile.mkdtemp()
        test_file = os.path.join(test_dir, 'vulnerable_app.py')
        
        with open(test_file, 'w') as f:
            f.write(create_test_vulnerable_app())
        
        print(f"\n[+] Created test vulnerable app: {test_file}")
        print("[+] Analyzing for security vulnerabilities...\n")
        analyzer.analyze_file(test_file)
        shutil.rmtree(test_dir)
    
    report = analyzer.generate_report(output)
    print(f"\n{Fore.GREEN}[+] Analysis complete!{Fore.RESET}")
    print(f"{Fore.GREEN}[+] Found {len(analyzer.vulns)} vulnerabilities{Fore.RESET}")

if __name__ == '__main__':
    main()
